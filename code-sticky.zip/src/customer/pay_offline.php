<center><!--  center Begin  -->
    
    <h1> Pay Offline Using Method </h1>
    
    <p class="text-muted">
        
        If you have any questions, feel free to <a href="../contact.php">Contact Us</a>. Our Customer Service work <strong>24/7</strong>
        
    </p>
    
</center><!--  center Finish  -->


<hr>


<div class="table-responsive"><!--  table-responsive Begin  -->
    
    <table class="table table-bordered table-hover table-striped"><!--  table table-bordered table-hover Begin  -->
        
        <thead><!--  thead Begin  -->
            
            <tr><!--  tr Begin  -->
            
                <th> Bank Account Details: </th>
                <th> Paytm Bank, Noida UP, UPI  Details: </th>


            </tr><!--  tr Finish  -->
            
        </thead><!--  thead Finish  -->
        
        <tbody><!--  tbody Begin  -->
           
           <td> Bank Name: Paytm | Account No: 918271388851 | Branch Name: Noida | Branch Code: 011 </td>
           <td>  addy88851@paytm | Mobile No: 8271388851 | Name: Aditya Raj </td>
            
        </tbody><!--  tbody Finish  -->
        
    </table><!--  table table-bordered table-hover Finish  -->
    
</div><!--  table-responsive Finish  -->